<!-- wp:pattern {"slug":"twentytwentythree/footer-default"} /-->
</body>
</html>